export function HeaderBar() {
  return (
    <div className="headerBar">
        <h1>QuickBrowse</h1>
  </div>
  );
}